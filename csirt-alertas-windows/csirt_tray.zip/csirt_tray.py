#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CSIRT Alertas — versión Windows (bandeja del sistema).

Réplica de la extensión de GNOME Shell: muestra las últimas alertas de
ciberseguridad del CSIRT de Chile (https://csirt.gob.cl) desde un icono junto
al reloj de Windows, con el mismo diseño de tarjetas (badge por severidad,
chips de categoría y resumen de la página) y notificaciones de escritorio.

Requisitos:  pip install PySide6
Ejecutar:    pythonw csirt_tray.py
Aplicación creada por Anibal Segovia Poblete.
"""

import os
import re
import sys
import json
import html
import threading
import urllib.request
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import xml.etree.ElementTree as ET

from PySide6.QtCore import Qt, QTimer, QObject, Signal, QRectF, QPointF
from PySide6.QtGui import (
    QIcon, QPixmap, QPainter, QColor, QPen, QBrush, QPolygonF,
    QPainterPath, QFont, QAction,
)
from PySide6.QtWidgets import (
    QApplication, QSystemTrayIcon, QMenu, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QFrame, QScrollArea, QPushButton, QDialog, QSpinBox, QCheckBox,
    QFormLayout, QSizePolicy,
)

# --------------------------------------------------------------------------
# Constantes / configuración
# --------------------------------------------------------------------------

APP_NAME = "CSIRT Alertas"
RSS_URL = "https://csirt.gob.cl/rss/alertas"
ALERTS_URL = "https://csirt.gob.cl/alertas/"
REPO_URL = "https://github.com/critercl/csirt-alertas"
USER_AGENT = "csirt-alertas-win/1.0"

# Colores por severidad (idénticos a la extensión de GNOME).
SEV_TINT = {
    "default":  "rgba(79,156,245,52)",
    "phishing": "rgba(245,166,35,52)",
    "vuln":     "rgba(239,108,59,52)",
    "malware":  "rgba(229,72,77,56)",
}
SEV_FG = {
    "default":  "#4f9cf5",
    "phishing": "#f5a623",
    "vuln":     "#ef6c3b",
    "malware":  "#e5484d",
}
# Borde (filtro inactivo) y relleno (filtro activo) por severidad.
SEV_BORDER = {
    "all":      "rgba(255,255,255,0.22)",
    "default":  "rgba(79,156,245,0.5)",
    "phishing": "rgba(245,166,35,0.5)",
    "vuln":     "rgba(239,108,59,0.5)",
    "malware":  "rgba(229,72,77,0.5)",
}
SEV_ACTIVE = {
    "all":      "rgba(255,255,255,0.90)",
    "default":  "rgba(79,156,245,0.90)",
    "phishing": "rgba(245,166,35,0.90)",
    "vuln":     "rgba(239,108,59,0.95)",
    "malware":  "rgba(229,72,77,0.95)",
}
FILTERS = [
    ("all", "Todas"),
    ("default", "Info"),
    ("phishing", "Fraude"),
    ("vuln", "Vuln."),
    ("malware", "Crítico"),
]

NOISE_CATEGORIES = {"Alerta", "No Caigas"}

DEFAULT_CONFIG = {
    "refresh_interval": 15,   # minutos
    "max_items": 10,
    "notify_new": True,
    "last_seen_guid": "",
}


def _appdata_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, APP_NAME)
    os.makedirs(d, exist_ok=True)
    return d


def _cache_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    d = os.path.join(base, APP_NAME, "cache")
    os.makedirs(d, exist_ok=True)
    return d


CONFIG_PATH = os.path.join(_appdata_dir(), "config.json")
SUMMARY_CACHE_PATH = os.path.join(_cache_dir(), "resumenes.json")
ITEMS_CACHE_PATH = os.path.join(_cache_dir(), "alertas.json")


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
            if isinstance(data, type(default)):
                return data
    except Exception:
        pass
    return default


def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
    except Exception:
        pass


# --------------------------------------------------------------------------
# Parseo del feed y del resumen
# --------------------------------------------------------------------------

def parse_rss(xml_bytes):
    items = []
    root = ET.fromstring(xml_bytes)
    channel = root.find("channel")
    if channel is None:
        return items
    for it in channel.findall("item"):
        title = (it.findtext("title") or "").strip()
        link = (it.findtext("link") or "").strip()
        guid = (it.findtext("guid") or link).strip()
        pub = (it.findtext("pubDate") or "").strip()
        cats = [c.text.strip() for c in it.findall("category")
                if c.text and c.text.strip()]
        if title and link:
            items.append({
                "title": title, "link": link, "guid": guid,
                "pubDate": pub, "categories": cats,
            })
    return items


_SKIP_RE = re.compile(
    r"Gobierno de Chile|Twitter|Mastodon|Telegram|verifico|"
    r"portal principal|Descargar Informe|Sitio\s+oficial", re.I)


def extract_summary(html_text):
    paras = []
    for m in re.finditer(r"<p[^>]*>([\s\S]*?)</p>", html_text, re.I):
        t = re.sub(r"<[^>]+>", "", m.group(1))
        t = html.unescape(t)
        t = re.sub(r"\s+", " ", t).strip()
        if len(t) >= 60 and not _SKIP_RE.search(t):
            paras.append(t)
    if not paras:
        return ""
    s = paras[0]
    if len(paras) > 1 and len(s) < 160:
        s = f"{s} {paras[1]}"
    if len(s) > 320:
        s = s[:317] + "…"
    return s


def relative_date(pub):
    try:
        dt = parsedate_to_datetime(pub)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    except Exception:
        return pub or ""
    diff = (datetime.now(timezone.utc) - dt).total_seconds()
    if diff < 60:
        return "hace un momento"
    if diff < 3600:
        return f"hace {int(diff // 60)} min"
    if diff < 86400:
        return f"hace {int(diff // 3600)} h"
    days = int(diff // 86400)
    if days < 30:
        return f"hace {days} d"
    return dt.strftime("%d-%m-%Y")


def severity_for(it):
    text = f"{it['title']} {' '.join(it['categories'])}".lower()
    if re.search(r"vulnerab|cve|exploit|parche|actualiz", text):
        return "vuln"
    if re.search(r"ransom|malware|troyano|botnet|backdoor", text):
        return "malware"
    if re.search(r"phishing|fraude|estafa|suplant|falso|falsific", text):
        return "phishing"
    return "default"


# --------------------------------------------------------------------------
# Iconos dibujados (para verse igual a los símbolos de GNOME)
# --------------------------------------------------------------------------

def _glyph_pixmap(sev, size=20, color=None):
    color = color or SEV_FG[sev]
    scale = 4  # supersampling para bordes nítidos
    s = size * scale
    pm = QPixmap(s, s)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)
    pen = QPen(QColor(color))
    pen.setWidthF(s * 0.11)
    pen.setJoinStyle(Qt.RoundJoin)
    pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)

    if sev == "phishing":
        # Triángulo de advertencia con signo de exclamación
        tri = QPolygonF([
            QPointF(s * 0.5, s * 0.14),
            QPointF(s * 0.9, s * 0.84),
            QPointF(s * 0.1, s * 0.84),
        ])
        p.drawPolygon(tri)
        p.drawLine(QPointF(s * 0.5, s * 0.38), QPointF(s * 0.5, s * 0.62))
        p.setBrush(QBrush(QColor(color)))
        p.drawEllipse(QPointF(s * 0.5, s * 0.73), s * 0.045, s * 0.045)
    elif sev == "malware":
        # "Bicho": cuerpo + antenas + patas
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(QRectF(s * 0.30, s * 0.34, s * 0.40, s * 0.46))
        p.drawLine(QPointF(s * 0.40, s * 0.30), QPointF(s * 0.30, s * 0.16))
        p.drawLine(QPointF(s * 0.60, s * 0.30), QPointF(s * 0.70, s * 0.16))
        for y in (0.45, 0.58, 0.71):
            p.drawLine(QPointF(s * 0.30, s * y), QPointF(s * 0.14, s * (y + 0.02)))
            p.drawLine(QPointF(s * 0.70, s * y), QPointF(s * 0.86, s * (y + 0.02)))
    else:
        # Escudo (pentágono). vuln => "!", default => check
        shield = QPolygonF([
            QPointF(s * 0.5, s * 0.10),
            QPointF(s * 0.86, s * 0.24),
            QPointF(s * 0.86, s * 0.52),
            QPointF(s * 0.5, s * 0.90),
            QPointF(s * 0.14, s * 0.52),
            QPointF(s * 0.14, s * 0.24),
        ])
        p.drawPolygon(shield)
        if sev == "vuln":
            p.drawLine(QPointF(s * 0.5, s * 0.32), QPointF(s * 0.5, s * 0.55))
            p.setBrush(QBrush(QColor(color)))
            p.drawEllipse(QPointF(s * 0.5, s * 0.66), s * 0.045, s * 0.045)
        else:
            path = QPainterPath()
            path.moveTo(s * 0.34, s * 0.48)
            path.lineTo(s * 0.46, s * 0.60)
            path.lineTo(s * 0.68, s * 0.34)
            p.drawPath(path)
    p.end()
    return pm.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)


def _tray_icon(count=0):
    size = 64
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)
    pen = QPen(QColor("#66bb6a"))
    pen.setWidthF(size * 0.09)
    pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen)
    shield = QPolygonF([
        QPointF(size * 0.5, size * 0.10),
        QPointF(size * 0.85, size * 0.24),
        QPointF(size * 0.85, size * 0.52),
        QPointF(size * 0.5, size * 0.90),
        QPointF(size * 0.15, size * 0.52),
        QPointF(size * 0.15, size * 0.24),
    ])
    p.drawPolygon(shield)
    path = QPainterPath()
    path.moveTo(size * 0.35, size * 0.46)
    path.lineTo(size * 0.46, size * 0.58)
    path.lineTo(size * 0.68, size * 0.34)
    p.drawPath(path)
    if count > 0:
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(QColor("#d32f2f")))
        r = size * 0.42
        p.drawEllipse(QRectF(size - r - 2, 2, r, r))
        p.setPen(QPen(QColor("white")))
        f = QFont()
        f.setPixelSize(int(r * 0.62))
        f.setBold(True)
        p.setFont(f)
        txt = "99+" if count > 99 else str(count)
        p.drawText(QRectF(size - r - 2, 2, r, r), Qt.AlignCenter, txt)
    p.end()
    return QIcon(pm)


# --------------------------------------------------------------------------
# Señales entre el hilo de red y la GUI
# --------------------------------------------------------------------------

class Bridge(QObject):
    results = Signal(list)
    error = Signal(str)


# --------------------------------------------------------------------------
# Ventana emergente (lista de alertas), estilo idéntico a GNOME
# --------------------------------------------------------------------------

POPUP_QSS = """
#card { background: transparent; border-radius: 10px; }
#card:hover { background: rgba(255,255,255,0.06); }
#title { color: #ffffff; font-weight: 600; font-size: 13px; }
#date  { color: rgba(255,255,255,0.5); font-size: 11px; }
#summary { color: rgba(255,255,255,0.72); font-size: 12px; }
#chip {
    color: rgba(255,255,255,0.85); font-size: 10px; font-weight: 600;
    background: rgba(255,255,255,0.10); border-radius: 6px; padding: 1px 8px;
}
#chipMore {
    color: rgba(255,255,255,0.6); font-size: 10px; font-weight: 600;
    background: rgba(255,255,255,0.06); border-radius: 6px; padding: 1px 8px;
}
#footerBtn {
    color: #e8e8e8; background: transparent; border: none;
    text-align: left; padding: 7px 10px; border-radius: 8px; font-size: 12px;
}
#footerBtn:hover { background: rgba(255,255,255,0.08); }
QScrollBar:vertical {
    background: transparent; width: 8px; margin: 2px 2px 2px 0;
}
QScrollBar::handle:vertical {
    background: rgba(255,255,255,0.22); border-radius: 4px; min-height: 28px;
}
QScrollBar::handle:vertical:hover { background: rgba(255,255,255,0.38); }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
"""


class AlertPopup(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.root = QFrame(self)
        self.root.setObjectName("root")
        self.root.setStyleSheet(
            "#root { background: #2b2b2e; border: 1px solid "
            "rgba(255,255,255,0.08); border-radius: 14px; }" + POPUP_QSS)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self.root)

        lay = QVBoxLayout(self.root)
        lay.setContentsMargins(6, 8, 6, 8)
        lay.setSpacing(2)

        self.header = QLabel("Alertas CSIRT")
        self.header.setStyleSheet(
            "color:#fff; font-weight:600; font-size:14px; padding:6px 10px;")
        lay.addWidget(self.header)

        # Barra de filtros con contadores (igual que en GNOME)
        self._active_filter = "all"
        self._filter_buttons = {}
        fbar = QHBoxLayout()
        fbar.setContentsMargins(10, 0, 10, 4)
        fbar.setSpacing(6)
        for key, label in FILTERS:
            btn = QPushButton(label)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, k=key: self.set_filter(k))
            self._filter_buttons[key] = (btn, label)
            btn.setStyleSheet(self._filter_style(key, key == self._active_filter))
            fbar.addWidget(btn)
        fbar.addStretch(1)
        lay.addLayout(fbar)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("background: transparent;")
        self.list_host = QWidget()
        self.list_host.setStyleSheet("background: transparent;")
        self.list_lay = QVBoxLayout(self.list_host)
        self.list_lay.setContentsMargins(0, 0, 0, 0)
        self.list_lay.setSpacing(1)
        self.scroll.setWidget(self.list_host)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setMinimumHeight(300)
        self.scroll.setMaximumHeight(560)
        lay.addWidget(self.scroll, 1)

        # Pie con acciones (equivalente a las entradas del menú de GNOME)
        sep = QFrame()
        sep.setFixedHeight(1)
        sep.setStyleSheet("background: rgba(255,255,255,0.08);")
        lay.addWidget(sep)

        self._add_footer(lay, "Actualizar ahora", self.app.refresh_now)
        self._add_footer(lay, "Abrir csirt.gob.cl",
                         lambda: self.app.open_uri(ALERTS_URL))
        self._add_footer(lay, "Preferencias", self.app.open_prefs)

        self.setFixedWidth(392)
        self.setStatus("Cargando…")

    def _add_footer(self, lay, text, cb):
        btn = QPushButton(text)
        btn.setObjectName("footerBtn")
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda: (self.hide(), cb()))
        lay.addWidget(btn)

    def _filter_style(self, sev, active):
        if active:
            fg = "#1b1b1b" if sev in ("all", "phishing") else "#ffffff"
            return (f"color:{fg}; background:{SEV_ACTIVE[sev]}; "
                    "border:1px solid transparent; border-radius:11px; "
                    "padding:3px 11px; font-size:11px; font-weight:600;")
        return ("color: rgba(255,255,255,0.82); background: transparent; "
                f"border:1px solid {SEV_BORDER[sev]}; border-radius:11px; "
                "padding:3px 11px; font-size:11px;")

    def set_filter(self, key):
        self._active_filter = key
        self.render_items(self.app.items, self.app.config["max_items"])

    def _clear_list(self):
        while self.list_lay.count():
            item = self.list_lay.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def setStatus(self, text):
        self._clear_list()
        lbl = QLabel(text)
        lbl.setStyleSheet(
            "color: rgba(255,255,255,0.6); font-style: italic; padding: 10px;")
        self.list_lay.addWidget(lbl)
        self.list_lay.addStretch(1)

    def render_items(self, items, max_items):
        # Contadores por tipo y actualización de los filtros
        counts = {"default": 0, "phishing": 0, "vuln": 0, "malware": 0}
        for it in items:
            s = severity_for(it)
            if s in counts:
                counts[s] += 1
        for key, (btn, label) in self._filter_buttons.items():
            n = len(items) if key == "all" else counts.get(key, 0)
            btn.setText(f"{label} {n}")
            btn.setStyleSheet(self._filter_style(key, key == self._active_filter))

        # Filtrado según el tipo activo
        if self._active_filter and self._active_filter != "all":
            filtered = [it for it in items
                        if severity_for(it) == self._active_filter]
        else:
            filtered = items

        self._clear_list()
        shown = filtered[:max_items]
        if not shown:
            self.setStatus("Sin alertas de este tipo"
                           if self._active_filter != "all"
                           else "Sin alertas disponibles")
            return
        for it in shown:
            self.list_lay.addWidget(self._make_card(it))
        self.list_lay.addStretch(1)

    def _make_card(self, it):
        sev = severity_for(it)
        card = QFrame()
        card.setObjectName("card")
        card.setCursor(Qt.PointingHandCursor)
        row = QHBoxLayout(card)
        row.setContentsMargins(10, 9, 10, 9)
        row.setSpacing(12)

        badge = QLabel()
        badge.setFixedSize(38, 38)
        badge.setAlignment(Qt.AlignCenter)
        badge.setPixmap(_glyph_pixmap(sev, 20))
        badge.setStyleSheet(
            f"background: {SEV_TINT[sev]}; border-radius: 10px;")
        row.addWidget(badge, 0, Qt.AlignTop)

        col = QVBoxLayout()
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(3)

        title = QLabel(it["title"])
        title.setObjectName("title")
        title.setWordWrap(True)
        col.addWidget(title)

        meta = QHBoxLayout()
        meta.setContentsMargins(0, 0, 0, 0)
        meta.setSpacing(6)
        date = QLabel(relative_date(it["pubDate"]))
        date.setObjectName("date")
        meta.addWidget(date)
        cats = [c for c in it["categories"] if c not in NOISE_CATEGORIES]
        for c in cats[:2]:
            chip = QLabel(c)
            chip.setObjectName("chip")
            meta.addWidget(chip)
        if len(cats) > 2:
            more = QLabel(f"+{len(cats) - 2}")
            more.setObjectName("chipMore")
            meta.addWidget(more)
        meta.addStretch(1)
        col.addLayout(meta)

        summary = it.get("summary", "")
        if summary:
            slbl = QLabel(summary)
            slbl.setObjectName("summary")
            slbl.setWordWrap(True)
            col.addWidget(slbl)

        row.addLayout(col, 1)
        card.mousePressEvent = lambda e, url=it["link"]: (
            self.hide(), self.app.open_uri(url))
        return card

    def popup_near_tray(self):
        self.adjustSize()
        geo = QApplication.primaryScreen().availableGeometry()
        w = max(self.width(), 392)
        h = min(self.sizeHint().height(), int(geo.height() * 0.8))
        self.resize(w, h)
        x = geo.right() - w - 12
        y = geo.bottom() - h - 12
        self.move(max(geo.left() + 8, x), max(geo.top() + 8, y))
        self.show()
        self.raise_()
        self.activateWindow()

    def focusOutEvent(self, event):
        self.hide()
        super().focusOutEvent(event)


# --------------------------------------------------------------------------
# Diálogo de preferencias (aplica en vivo)
# --------------------------------------------------------------------------

class PrefsDialog(QDialog):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.setWindowTitle(f"{APP_NAME} — Preferencias")
        self.setMinimumWidth(360)
        form = QFormLayout(self)

        self.interval = QSpinBox()
        self.interval.setRange(1, 1440)
        self.interval.setSuffix(" min")
        self.interval.setValue(app.config["refresh_interval"])
        self.interval.valueChanged.connect(self._on_interval)
        form.addRow("Intervalo de actualización", self.interval)

        self.maxitems = QSpinBox()
        self.maxitems.setRange(1, 30)
        self.maxitems.setValue(app.config["max_items"])
        self.maxitems.valueChanged.connect(self._on_max)
        form.addRow("Alertas a mostrar", self.maxitems)

        self.notify = QCheckBox("Notificar nuevas alertas")
        self.notify.setChecked(app.config["notify_new"])
        self.notify.toggled.connect(self._on_notify)
        form.addRow(self.notify)

        info = QLabel(f'<a href="{REPO_URL}">Código fuente</a>'
                      '<br>Aplicación creada por Anibal Segovia Poblete')
        info.setOpenExternalLinks(True)
        form.addRow(info)

    def _on_interval(self, v):
        self.app.config["refresh_interval"] = v
        self.app.save_config()
        self.app.reschedule()

    def _on_max(self, v):
        self.app.config["max_items"] = v
        self.app.save_config()
        self.app.rerender()

    def _on_notify(self, checked):
        self.app.config["notify_new"] = checked
        self.app.save_config()


# --------------------------------------------------------------------------
# Aplicación principal
# --------------------------------------------------------------------------

class CsirtApp:
    def __init__(self):
        self.qapp = QApplication(sys.argv)
        self.qapp.setQuitOnLastWindowClosed(False)

        self.config = dict(DEFAULT_CONFIG)
        self.config.update(load_json(CONFIG_PATH, {}))
        self.summary_cache = load_json(SUMMARY_CACHE_PATH, {})
        self.items = load_json(ITEMS_CACHE_PATH, [])

        self.bridge = Bridge()
        self.bridge.results.connect(self.on_results)
        self.bridge.error.connect(self.on_error)

        self.popup = AlertPopup(self)
        if self.items:
            self.popup.render_items(self.items, self.config["max_items"])

        self.tray = QSystemTrayIcon(_tray_icon(0))
        self.tray.setToolTip(APP_NAME)
        self.tray.activated.connect(self.on_tray_activated)
        self.tray.messageClicked.connect(self.on_message_clicked)

        # Se guardan como atributos: si fueran locales, Python los liberaría
        # (GC) al terminar __init__ y Qt quedaría con punteros colgantes
        # -> Access Violation. Mantener referencias vivas es obligatorio.
        self._menu = QMenu()
        act_open = QAction("Ver alertas", self._menu)
        act_open.triggered.connect(self.toggle_popup)
        act_refresh = QAction("Actualizar ahora", self._menu)
        act_refresh.triggered.connect(self.refresh_now)
        act_site = QAction("Abrir csirt.gob.cl", self._menu)
        act_site.triggered.connect(lambda: self.open_uri(ALERTS_URL))
        act_prefs = QAction("Preferencias", self._menu)
        act_prefs.triggered.connect(self.open_prefs)
        act_quit = QAction("Salir", self._menu)
        act_quit.triggered.connect(self.qapp.quit)
        self._actions = [act_open, act_refresh, act_site, act_prefs, act_quit]
        for a in (act_open, act_refresh, act_site, act_prefs):
            self._menu.addAction(a)
        self._menu.addSeparator()
        self._menu.addAction(act_quit)
        self.tray.setContextMenu(self._menu)
        self.tray.show()

        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh_now)
        self.reschedule()

        self._newest_link = None
        self._prefs = None
        QTimer.singleShot(500, self.refresh_now)

    # ---- ciclo de vida ----
    def run(self):
        return self.qapp.exec()

    def save_config(self):
        save_json(CONFIG_PATH, self.config)

    def reschedule(self):
        minutes = max(1, int(self.config["refresh_interval"]))
        self.timer.start(minutes * 60 * 1000)

    def rerender(self):
        self.popup.render_items(self.items, self.config["max_items"])

    # ---- interacción ----
    def on_tray_activated(self, reason):
        if reason == QSystemTrayIcon.Trigger:
            self.toggle_popup()

    def toggle_popup(self):
        if self.popup.isVisible():
            self.popup.hide()
        else:
            self.popup.render_items(self.items, self.config["max_items"])
            self.popup.popup_near_tray()

    def open_uri(self, uri):
        import webbrowser
        webbrowser.open(uri)

    def open_prefs(self):
        self._prefs = PrefsDialog(self)
        self._prefs.show()
        self._prefs.raise_()
        self._prefs.activateWindow()

    def on_message_clicked(self):
        if self._newest_link:
            self.open_uri(self._newest_link)

    # ---- red ----
    def refresh_now(self):
        threading.Thread(target=self._do_fetch, daemon=True).start()

    def _fetch(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read()

    def _do_fetch(self):
        try:
            items = parse_rss(self._fetch(RSS_URL))
        except Exception as exc:  # noqa: BLE001
            self.bridge.error.emit(str(exc))
            return
        for it in items[:self.config["max_items"]]:
            if it["guid"] in self.summary_cache:
                it["summary"] = self.summary_cache[it["guid"]]
                continue
            try:
                page = self._fetch(it["link"]).decode("utf-8", "replace")
                summary = extract_summary(page)
            except Exception:  # noqa: BLE001
                summary = ""
            it["summary"] = summary
            if summary:
                self.summary_cache[it["guid"]] = summary
        save_json(SUMMARY_CACHE_PATH, self.summary_cache)
        self.bridge.results.emit(items)

    def on_error(self, msg):
        if not self.items:
            self.popup.setStatus("Error de conexión")

    def on_results(self, items):
        if not items:
            return
        self.items = items
        save_json(ITEMS_CACHE_PATH, items[:30])

        last_seen = self.config.get("last_seen_guid", "")
        new_count = 0
        for it in items:
            if it["guid"] == last_seen:
                break
            new_count += 1
        if last_seen == "":
            new_count = 0

        self.rerender()
        self.tray.setIcon(_tray_icon(new_count))

        # Tooltip con la segmentación por tipo (como los contadores del panel)
        counts = {"default": 0, "phishing": 0, "vuln": 0, "malware": 0}
        for it in items:
            s = severity_for(it)
            if s in counts:
                counts[s] += 1
        seg = "  ·  ".join(
            f"{lbl} {counts[k]}"
            for k, lbl in (("default", "Info"), ("phishing", "Fraude"),
                           ("vuln", "Vuln."), ("malware", "Crítico"))
            if counts[k] > 0)
        head = f"{APP_NAME} — {new_count} nuevas" if new_count else APP_NAME
        self.tray.setToolTip(f"{head}\n{seg}" if seg else head)

        if new_count > 0 and self.config["notify_new"]:
            self._newest_link = items[0]["link"]
            top = items[:min(new_count, 3)]
            body = "\n".join(f"• {i['title']}" for i in top)
            title = ("Nueva alerta CSIRT" if new_count == 1
                     else f"{new_count} nuevas alertas CSIRT")
            self.tray.showMessage(
                title, body, _tray_icon(new_count), 10000)

        self.config["last_seen_guid"] = items[0]["guid"]
        self.save_config()


def _log_error(text):
    try:
        with open(os.path.join(_appdata_dir(), "app.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(text + "\n")
    except Exception:
        pass


def main():
    # El QApplication debe existir ANTES de consultar la bandeja del sistema.
    try:
        app = CsirtApp()
    except Exception:
        import traceback
        tb = traceback.format_exc()
        _log_error(tb)
        print(tb, file=sys.stderr)
        return 1

    if not QSystemTrayIcon.isSystemTrayAvailable():
        print("Aviso: la bandeja del sistema no se reporta como disponible; "
              "el icono podría no verse.", file=sys.stderr)

    return app.run()


if __name__ == "__main__":
    sys.exit(main())
